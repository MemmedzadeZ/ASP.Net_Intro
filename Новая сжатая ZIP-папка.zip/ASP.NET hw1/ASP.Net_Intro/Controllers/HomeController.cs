﻿using ASP.Net_Intro.Entities;
using ASP.Net_Intro.Models;
using ASP.Net_Intro.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ASP.Net_Intro.Controllers
{
    public class HomeController : Controller
    {






        List<Drink> drones = new List<Drink>()
            {
                new Drink()
                {
                    Id= 1,
                    Name="Latte",
                    price=4,

                },
                  new Drink()
                {
                    Id= 2,
                    Name="Iced Tea",
                    price=2,
                },
                    new Drink()
                {
                    Id= 3,
                    Name="Americano",
                    price=5,
                },

            };



      
            List<FastFood> fastFoods = new List<FastFood>()
            {
                new FastFood()
                {
                    Id= 1,
                    Name="Cheeseburger",
                    price=4,
                },
                new FastFood()
                {
                    Id= 2,
                    Name="Pizza",
                    price=8,
                },
                new FastFood()
                {
                    Id= 3,
                    Name = "sandwich",
                    price=4,
                }
            };
          

        
            List<HotMeal> hotMeals = new List<HotMeal>()
            {
                new HotMeal()
                {
                    Id= 1,
                    Name="Spaghetti Bolognese",
                    price=12,
                },
                new HotMeal()
                {
                    Id= 2,
                    Name="Tomato Soup",
                    price=16,
                },
                new HotMeal()
                {
                    Id= 3,
                    Name="Dushbara",
                    price=10,
                }


            };

        public IActionResult Index()
        {
            var vm = new DataTotalViewModels()
            {
                drinks = drones,
                hotMeal = hotMeals,
                fastFood = fastFoods

            };
            return View(vm);
        }


        public IActionResult Drinks()
            {
                return View(drones);
            }
            public IActionResult FastFoods()
            { 
                return View(fastFoods);
            }

            public IActionResult HotMeals()
            {
                return View(hotMeals);

            }
    }
}
