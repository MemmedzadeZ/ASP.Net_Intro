﻿namespace ASP.Net_Intro.Entities
{
    public class Employee
    {

        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
