﻿namespace ASP.Net_Intro.Entities
{
	public class FastFood
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public int price { get; set; }
	}
}
